# 🎓 Online Kütüphane API - OpenAPI Tanımı

Bu proje, Açık Kaynak Kodlu Yazılımlar dersi kapsamında hazırlanmış bir RESTful API tanımıdır. API, bir üniversitenin çevrim içi kütüphane sistemine yönelik olup OpenAPI 3.0.3 standardına göre yazılmıştır.

## 📁 İçerik
- `openapi.yaml`: API'nin tam tanımı
- `DELIVERY.md`: Teslim için gerekli açıklamaları içeren dosya

## 🚀 Özellikler
- Kitap, öğrenci ve ödünç işlemleri için CRUD endpoint'leri
- Path ve query parametre örnekleri
- Veri doğrulama (UUID, email, ISBN-13)
- Sayfalama desteği (GET /books)
- Açıklayıcı `components/schemas` tanımları
- Hata yanıtları: 400, 404, 500

## 🧪 Test
Swagger Editor kullanarak test etmek için:
- https://editor.swagger.io adresine gidin
- `openapi.yaml` içeriğini yapıştırın
- Endpoint'leri test edin
