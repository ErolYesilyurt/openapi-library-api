# 📦 OpenAPI Tasarımı Ödevi Teslim Raporu

## 👤 Öğrenci Bilgileri
- **Ad Soyad**: Erol Yeşilyurt
- **Öğrenci Numarası**: 170422058

---

## 📂 OpenAPI YAML Dosyası

### 🔗 GitHub Repo Linki
[https://github.com/ErolYesilyurt/openapi-library-api]

---

## 📝 API Açıklaması

Bu projede üç temel varlık tanımlanmıştır:

1. **books**: Kitap bilgileri (UUID, başlık, yazar, ISBN, stok vb.)
2. **students**: Öğrenci bilgileri (UUID, ad, öğrenci no, e-posta)
3. **loans**: Kitap ödünç işlemleri (UUID, tarih, iade durumu)

### CRUD Endpoint'ler
Her varlık için GET, POST, PUT, DELETE işlemleri detaylı şekilde tanımlanmıştır.

### Schemas ve Parametreler
- `components/schemas` altında tüm veri modelleri oluşturulmuştur.
- Path ve query parametreleri kullanılmıştır.
  - Örneğin: `GET /books?page=1&size=10`

### Sayfalama
- `GET /books` endpoint’i sayfalama parametreleri (`page`, `size`) ile çalışır.

### Hata Durumları
- `404 Not Found`, `400 Bad Request`, `500 Internal Server Error` örnekleri hazırlanmıştır.

---

## 🧪 Test Notları (Opsiyonel)

- `GET /books`: Başarıyla kitap listesi döndürülmüştür.
- `POST /students`: Gerekli tüm alanlarla başarılı bir kayıt eklenmiştir.
- `PATCH /loans/{id}/return`: İade işlemi başarıyla tamamlanmıştır.
- Hatalı UUID ile yapılan istekte `404` yanıtı alınmıştır.

---

## 📌 Ek Açıklamalar

- Swagger Editor üzerinden testler yapılmış ve dosya geçerliliği onaylanmıştır.
- API, gelecekte kullanıcı kimlik doğrulaması (API Key) gibi özelliklerle genişletilebilir.
